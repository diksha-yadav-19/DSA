#include <iostream>
#include <vector>
using namespace std;

class PROCESS
{
public:
    int getmax(vector<int> &ary)
    {
        int max = ary[0];
        for (int i = 0; i < ary.size(); i++)
        {
            if (max < ary[i])
            {
                max = ary[i];
            }
        }
        return max;
    }

    vector<int> getEvenAry(vector<int> ary)
    {
        vector<int> bhai;
        for (int i = 0; i < ary.size(); i++)
        {
            if (ary[i] % 2 == 0)
            {
                bhai.push_back(ary[i]);
            }
        }
        return bhai;
    }
};

int main()
{
    vector<int> ary(5);
    cout << "Enter 5 integers: ";
    for (int i = 0; i < ary.size(); i++)
    {
        cin >> ary[i];
    }
    PROCESS obj;

    int max = obj.getmax(ary);
    cout << "Max value: " << max << endl;

    vector<int> evenAry = obj.getEvenAry(ary);
    cout << "Even elements: ";
    for (int i = 0; i < evenAry.size(); i++)
    {
        cout << evenAry[i] << " ";
    }
    cout << endl;

    return 0;
}

