#include <iostream>
#include <stack>
using namespace std;

void findGreatest(stack<int> stk, int &max) {
    if (stk.empty())
        return;

    int val = stk.top();
    stk.pop();

    findGreatest(stk, max);

    if (val > max)
        max = val;

    stk.push(val);
}

int main() {
    stack<int> stk;
    stk.push(10);
    stk.push(20);
    stk.push(5);
    stk.push(35);
    stk.push(115);

    int maxValue = stk.top();
    findGreatest(stk, maxValue);

    cout << "Greatest element in the stack: " << maxValue << endl;

    return 0;
}
