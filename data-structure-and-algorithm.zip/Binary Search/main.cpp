#include <iostream>
#include <vector>
using namespace std;

int BinarySearch(vector<int> arr, int wanted) {
    int start = 0, end = arr.size() - 1;
    while (start <= end) { 
        int mid = start + (end - start) / 2;
        if (arr[mid] == wanted) {
            return mid;
        } else if (wanted < arr[mid]) {
            end = mid - 1;
        } else { 
            start = mid + 1;
        }
    }
    return -1;
}

int main() {
    vector<int> ary = {1, 3, 5, 7, 9, 11, 13, 15};
    int wanted = 11;
    int result = BinarySearch(ary, wanted);
    if (result != -1) {
        cout << "Element " << wanted << " found at index " << result << endl;
    } else {
        cout << "Element not found in the array." << endl;
    }
    return 0;
}

