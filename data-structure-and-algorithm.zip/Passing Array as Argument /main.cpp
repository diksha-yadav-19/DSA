#include <iostream>
using namespace std;

// 1. Formal parameters as pointers
int getMax1(int* arr, int size) {
  int max = arr[0];
  for (int i = 1; i < size; ++i) {
    if (arr[i] > max) {
      max = arr[i];
    }
  }
  return max;
}

// 2. Formal parameters as sized array
int getMax2(int arr[10], int size) {
  int max = arr[0];
  for (int i = 1; i < size; ++i) {
    if (arr[i] > max) {
      max = arr[i];
    }
  }
  return max;
}

// 3. Formal parameters as unsized array
int getMax3(int arr[], int size) {
  int max = arr[0];
  for (int i = 1; i < size; ++i) {
    if (arr[i] > max) {
      max = arr[i];
    }
  }
  return max;
}

int main() {
  int N = 4;
  int A[] = {5, 8, 9, 10};

  int max1 = getMax1(A, N);
  cout << "Maximum value (Type 1): " << max1 << endl;

  int max2 = getMax2(A, N);
  cout << "Maximum value (Type 2): " << max2 << endl;

  int max3 = getMax3(A, N);
  cout << "Maximum value (Type 3): " << max3 << endl;

  return 0;
}


