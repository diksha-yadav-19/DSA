//API APPLICATION PROGRAMMING INTERFACE 
// class STACK{
//     int *stk;
//     int index=-1; //top=-1
//     int cap;
//     public:
//     STACK(int N){
//         cap=N;
//         stk=new[cap]; //array of stack created 
//     }
// };
#include <iostream>
#include <stack>  // Include the <stack> header for the stack container
using namespace std;

void show(stack<int> &stk) {
    if (stk.empty())
        return;
    int val = stk.top();
    stk.pop();
    show(stk);
    cout << val << " ";
    stk.push(val);
}

int main() {
    stack<int> stk;
    stk.push(10);
    stk.push(20);
    stk.push(30);

    cout << "Stack elements: ";
    show(stk);
    cout << endl;
    cout<<"Size of Above Stack :"<<stk.size();

    return 0;
}

