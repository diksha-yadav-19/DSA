#include<iostream>
#include<map>
using namespace std;

int main() {
    string s;
    cout << "Enter the string: ";
    cin >> s;

    map<char, int> mp; // Declare a map to store characters as keys and their occurrences as values

    // Loop through each character in the string
    for (auto ch : s) {
        mp[ch]++; // Increment the count of the current character in the map
    }

    cout << "Output:\n";
    // Loop through the map and print each character and its occurrence count
    for (auto entry : mp) {
        cout << entry.first << ": " << entry.second << endl;
    }

    return 0;
}
