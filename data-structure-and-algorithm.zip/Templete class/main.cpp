#include <iostream>
using namespace std;

template<class T>
class Swap {
    T A, B, temp;
public:
    void setAB(T a1, T b1) {
        A = a1;
        B = b1;
        doswap();
    }

    void doswap() {
        temp = A;
        A = B;
        B = temp;
    }

    void show() {
        cout << A << " " << B << endl;
    }
};

int main() {
    Swap<int> iobj;
    Swap<char> cobj;
    Swap<float> fobj;

    iobj.setAB(4, 8);
    iobj.show();

    cobj.setAB('A', 'H');
    cobj.show();

    fobj.setAB(12.3, 45.9);
    fobj.show();

    return 0;
}
