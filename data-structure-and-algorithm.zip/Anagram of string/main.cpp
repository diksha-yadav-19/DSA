#include <iostream>
#include <map>

using namespace std;

int main() {
    string a, b;
    cout << "Enter the strings s1 and s2: ";
    cin >> a >> b;

    if (a.size() != b.size()) {
        cout << "not anagram";
        return 0;
    }

    map<char, int> Map1;
    for (auto ch : a) {
        Map1[ch]++;
    }

    map<char, int> Map2;
    for (auto ch : b) {
        Map2[ch]++;
    }

    if (Map1 == Map2) {
        cout << "anagram";
    } else {
        cout << "not anagram";
    }

    return 0;
}
