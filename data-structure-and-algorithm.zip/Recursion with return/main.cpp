#include <iostream>
#include <vector>
using namespace std;

int sum(vector<int>& arr, int N) {
    if (N == 0)
        return arr[0];
    
    int resp = sum(arr, N - 1);
    int sum = arr[N] + resp;
    return sum;
}

int main() {
    vector<int> arr = {1, 2, 3, 4, 5};
    int N = arr.size();

    int result = sum(arr, N - 1);
    cout << "Sum of the array: " << result << endl; // Output: Sum of the array: 15

    return 0;
}
