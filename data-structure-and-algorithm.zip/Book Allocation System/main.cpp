//book allocation system
#include <iostream>
#include <vector>
using namespace std;

bool isPossible(vector<int> &arr, int n, int m, int mid) {
    int studentCount = 1;
    int pageSum = 0;

    for (int i = 0; i < n; i++) {
        if (pageSum + arr[i] <= mid) {
            pageSum += arr[i];
        } else {
            studentCount++;
            pageSum = arr[i]; // Reset pageSum for the new student
        }
    }

    return (studentCount <= m);
}

int allocateBooks(vector<int> &arr, int n, int m) {
    int sum = 0;
    int result = -1;

    for (int i = 0; i < n; i++) {
        sum += arr[i];
    }

    int start = 0;
    int end = sum;

    while (start <= end) {
        int mid = start + (end - start) / 2;
        
        if (isPossible(arr, n, m, mid)) {
            result = mid;
            end = mid - 1;
        } else {
            start = mid + 1;
        }
    }

    return result;
}


int main() {
    vector<int> arr = {10, 20, 30, 40};//60
    int n = arr.size();
    int m = 2; // Number of students

    int minPages = allocateBooks(arr, n, m);
    cout << "Minimum pages: " << minPages << endl;

    return 0;
}
