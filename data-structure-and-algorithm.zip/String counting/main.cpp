#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Strings {
public:
    void docount(string s) {
        int i;
        for (i = 0; i < s.size(); i++) {
            char wanted = s[i];
            int fromindex = i - 1;// ek index phele se check hoga
            bool resp = check(s, wanted, fromindex); // function calling
            if (resp == false) {
                int count = 1;
                for (int j = i + 1; j < s.size(); j++) {
                    if (wanted == s[j])
                        count++;
                }
                cout << wanted << " Found " << count << " Times" << endl;
            }
        }
    }

    bool check(string s, int wanted, int fromindex) { // this condition check whether the character previously exist or not
        for (int i = fromindex; i >= 0; i--) {
            if (wanted == s[i])
                return true;
        }
        return false;
    }
};

int main() {
    Strings obj;
    string str;
    cout << "Enter the string: ";
    cin >> str;
    obj.docount(str);
    return 0;
}
