#include <iostream>
using namespace std;

void traverseArrayRecursive(int arr[], int index, int size) {
    if (index >= size) {
        cout << endl;
        return;
    }

    // cout << arr[index] << " ";   jate hue
    traverseArrayRecursive(arr, index + 1, size);
     cout << arr[index] << " ";  // wapis atte hue
 }

int main() {
    int arr[] = {10, 20, 30, 40, 50};
    int size = sizeof(arr) / sizeof(arr[0]);

    cout << "Array elements: ";
    traverseArrayRecursive(arr, 0, size);

    return 0;
}
