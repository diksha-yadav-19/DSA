//Linked List
#include<iostream>
using namespace std;

class NODE {
public:
    int info;
    NODE* next;

    NODE(int data) {
        info = data;
        next = NULL;
    }
};

class LinkedList {
public:
    void show(NODE* h) {
        NODE* ptr = h;
        while (ptr != NULL) {
            cout << ptr->info << " ";
            ptr = ptr->next;
        }
        cout << endl;
    }

    void showRec(NODE* ptr, int& sum) {
        if (ptr == NULL)
            return;

        sum += ptr->info;
        showRec(ptr->next, sum);
        cout << ptr->info << " ";
    }

    bool exist(NODE* ptr, int wanted) {
        if (ptr == NULL)
            return false;
        if (wanted == ptr->info)
            return true;
        return exist(ptr->next, wanted);
    }

    NODE* existsGetAddress(NODE* ptr, int wanted) {
        if (ptr == NULL)
            return NULL;
        if (wanted == ptr->info)
            return ptr;
        return existsGetAddress(ptr->next, wanted);
    }
};

int main() {
    NODE* head = NULL;
    NODE n1(10), n2(20), n3(30), n4(40), n5(50), n6(60); 

    head = &n1; 
    n1.next = &n2; 
    n2.next = &n3; 
    n3.next = &n4; 
    n4.next = &n5; 
    n5.next = &n6; 

    LinkedList linkedList;
    cout << "Linked List: ";
    linkedList.show(head);

    int sum = 0;
    linkedList.showRec(head, sum);
    cout << "\nSum of Elements: " << sum << endl;

    bool exists = linkedList.exist(head, 20);
    cout << "Existence of 20: " << (exists ? "Yes" : "No") << endl;

    NODE* foundNode = linkedList.existsGetAddress(head, 30);
    if (foundNode != NULL)
        cout << "Node address of 30: " << foundNode << endl;

    return 0;
}

