//Postfix Evaluation
#include <iostream>
#include <stack>
#include <cmath> // Include the <cmath> header for the pow function
using namespace std;

int postfixEvaluation(string s) {
    stack<int> stk;

    for (int i = 0; i < s.length(); i++) {
        char c = s[i];
        if (c >= '0' && c <= '9') {
            stk.push(c - '0'); // Convert char to int
        } else {
            int operand2 = stk.top();
            stk.pop();
            int operand1 = stk.top();
            stk.pop();

            switch (c) {
                case '+':
                    stk.push(operand1 + operand2);
                    break;
                case '-':
                    stk.push(operand1 - operand2);
                    break;
                case '*':
                    stk.push(operand1 * operand2);
                    break;
                case '/':
                    stk.push(operand1 / operand2);
                    break;
                case '^':
                    stk.push(pow(operand1, operand2));
                    break;
            }
        }
    }

    return stk.top();
}

int main() {
    string postfixExpression = "46+2/5*7+";
    int result = postfixEvaluation(postfixExpression);
    cout << "Result: " << result << endl;
    return 0;
}

