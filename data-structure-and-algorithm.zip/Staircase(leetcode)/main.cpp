#include <iostream>
using namespace std;

int countWaysToReachTop(int n) {
    if (n == 0 || n == 1)
        return 1;
    
    int rx = countWaysToReachTop(n - 1);
    int ry = countWaysToReachTop(n - 2);
    
    return rx + ry;
}

int main() {
    int n = 4; // Example: Number of steps in the staircase
    int ways = countWaysToReachTop(n);
    cout << "Number of ways to reach the top of the staircase with " << n << " steps: " << ways << endl;

    return 0;
}
