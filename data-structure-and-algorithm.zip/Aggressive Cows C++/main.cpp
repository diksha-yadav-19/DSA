//Aggressive Cows
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

bool isvaliddistance(vector<int>& stalls, int mid, int k);

int aggressiveCows(vector<int>& stalls, int k) {
    sort(stalls.begin(), stalls.end());
    int s = 1, e = stalls[stalls.size() - 1] - stalls[0]; // Fix the end point calculation

    while (s <= e) {
        int mid = s + (e - s) / 2;
        bool resp = isvaliddistance(stalls, mid, k);

        if (resp) {
            s = mid + 1; // Increase the distance to find a larger valid distance
        } else {
            e = mid - 1; // Decrease the distance to find a smaller valid distance
        }
    }
    return e; // Return the maximum valid distance
}

bool isvaliddistance(vector<int>& stalls, int mid, int k) {
    int count = 1;
    int pos = 0;
    for (int i = 1; i < stalls.size(); i++) { // Start from index 1
        int diff = stalls[i] - stalls[pos];
        if (diff >= mid) {
            count++;
            if (count == k)
                return true;
            pos = i;
        }
    }
    return false;
}

int main() {
    vector<int> stalls = { 1, 2, 8, 4, 9 };
    int k = 3;
    int result = aggressiveCows(stalls, k);
    cout << "Maximum valid distance: " << result << endl;
    return 0;
}

