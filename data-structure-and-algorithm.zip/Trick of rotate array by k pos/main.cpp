#include<iostream>
#include<vector>
using namespace std;

class BCE {
public:
    vector<int> rotate(vector<int> ary, int k) {
        int N = ary.size();
        vector<int> B(N); // Initialize vector B with size N
        for (int i = 0; i < N; i++) {
            int pos = (k + i) % N;
            B[pos] = ary[i];
        }
        return B; 
    }

    void show(vector<int> ary) {
        for (int i=0;i<ary.size();i++) {
            cout << ary[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    vector<int> ary = {3, 7, 9, 2, 6};
    BCE obj;

    vector<int> newary = obj.rotate(ary, 2);
    obj.show(ary);
    cout << endl;
    obj.show(newary);
   return 0;
}

