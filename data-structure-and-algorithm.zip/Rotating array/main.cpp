#include <iostream>
#include <vector>

using namespace std;

void leftRotate(vector<int>& arr, int k) {
    vector<int> b;
    for (int i = 0; i < k; i++) {
        b.push_back(arr[0]);
        for (int j = 0; j < arr.size() - 1; j++) {
            arr[j] = arr[j + 1];
        }
      arr[arr.size() - 1]=b[i] ;
    }
}

int main() {
    int n, k;
    cout << "Enter the number of elements in the array: ";
    cin >> n;
    cout << "Enter the value of k (the number of positions to rotate): ";
    cin >> k;

    vector<int> arr(n);
    for (int i = 0; i < arr.size(); i++) {
        cout << "Enter the value of array element " << i << ": ";
        cin >> arr[i];
    }

    leftRotate(arr, k);

    cout << "Left Rotated Array: ";
    for (int i = 0; i < arr.size(); i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}

