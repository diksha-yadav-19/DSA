#include <iostream>
#include <vector>
using namespace std;

int getpeak(vector<int> arr) {
    int s = 0, e = arr.size() - 1;
    while (s < e) {
        int mid = s + (e - s) / 2;
        if (arr[mid] < arr[mid + 1])
            s = mid + 1;
        else
            e = mid;
    }
    return s;
}

int main() {
    vector<int> arr = {40, 30, 20, 10, 6, 2};
    int peakIndex = getpeak(arr);
    cout << "Peak element: " << arr[peakIndex] << " at index " << peakIndex << endl;
    return 0;
}
