#include <iostream>
using namespace std;

int main() {
    int ASCII[256] = {0}; // Initialize an array to store the count of each ASCII character
    string s;
    cout<<"Enter the string:";
    cin >> s; // Input a string from the user

    // Loop through the characters in the string and update the count in the ASCII array
    for (int i = 0; i < s.size(); i++) {
        cout << s[i]; // Print the current character
        int Asciivalue = s[i]; // Get the ASCII value of the current character
        ASCII[Asciivalue]++; // Increment the count of the corresponding ASCII value
    }

    // Loop through the ASCII array to print the count of each character that appeared in the string
    for (int i = 0; i < 256; i++) {
        if (ASCII[i] != 0) { // Check if the count is not zero (character appeared in the string)
            cout << "\nCharacter '" << char(i) << "' Found " << ASCII[i] << " Times" << endl;
        }
    }

    return 0;
}
