#include <iostream>
#include <vector>
using namespace std;

class Quicksort
{
public:
    int Partition(vector<int> &arr, int lb, int ub)
    {
        int pivot = arr[lb];
        int start = lb;
        int end = ub;

        while (start < end)
        {
            while (arr[start] <= pivot)
            {
                start++;
            }
            while (arr[end] > pivot)
            {
                end--;
            }

            if (start < end)
                swap(arr[start], arr[end]);
        }
        swap(arr[lb], arr[end]);
        return end;
    }

    void QuickSort(vector<int> &arr, int lb, int ub)
    {
        if (lb < ub)
        {
            int loc = Partition(arr, lb, ub);
            QuickSort(arr, lb, loc - 1);
            QuickSort(arr, loc + 1, ub);
        }
    }
};

int main()
{
    vector<int> arr = {64, 25, 12, 22, 11};
    int n = arr.size();

    Quicksort qs;
    qs.QuickSort(arr, 0, n - 1);

    cout << "Sorted array: ";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}


