#include <iostream>
#include <vector>
using namespace std;

class BCE {
public:
    void firstAndLast(vector<int> ary, int wanted) {
        int fpos = -1; // Initialize fpos to -1 to indicate no match found initially
        int sp = -1;   // Initialize sp to -1 to indicate no match found initially

        for (int i = 0; i < ary.size(); i++) {
            if (fpos == -1 && wanted == ary[i]) {
                fpos = i; // Store the position of the first occurrence
            }
            if (wanted == ary[i]) {
                sp = i; // Store the position of the last occurrence
            }
        }
        cout << "\nFirst Pos = " << fpos << " Second Pos = " << sp;
    }
};

int main() {
    vector<int> ary = {3, 7, 7, 7, 7};
    BCE obj;
    obj.firstAndLast(ary, 7);

    return 0;
}
