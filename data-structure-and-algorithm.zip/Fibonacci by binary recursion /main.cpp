#include <iostream>
using namespace std;

int Fibonacci(int N) {
    if (N == 0 || N == 1)
        return N;

    int rx = Fibonacci(N - 1);
    int ry = Fibonacci(N - 2);
    int resp = rx + ry;
    return resp;
}

int main() {
    int N = 10; 
    int result = Fibonacci(N);
    cout << "The " << N << "th Fibonacci number is: " << result << endl;

    return 0;
}
