#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Bce {
public:
    vector<int> intersection(vector<int> arr1, vector<int> arr2) {
        vector<int> arr3;
        for (int i = 0; i < arr1.size(); i++) {
            int flag = 1;
            for (int j = 0; j < arr2.size(); j++) {
                if (arr1[i] == arr2[j]) {
                    flag = 0; // Set flag to 0 if the element is found in arr2
                    break;
                }
            }
            if (flag == 0) {
                if (find(arr3.begin(), arr3.end(), arr1[i]) == arr3.end()) { //trick
                    arr3.push_back(arr1[i]); // Add the element to arr3 if it is not already present
                }
            }
        }
        return arr3;
    }
};

int main() {
    Bce obj;

    vector<int> arr1 = {1, 2, 1, 3};
    vector<int> arr2 = {3, 2, 1, 2};

    vector<int> arr3 = obj.intersection(arr1, arr2);

    cout << "Intersection of the two arrays: ";
    for (int i = 0; i < arr3.size(); i++) {
        cout << arr3[i] << " ";
    }

    return 0;
}

