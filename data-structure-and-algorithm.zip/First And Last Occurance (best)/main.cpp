#include <iostream>
#include <vector>
using namespace std;

class Occurrence {
public:
    int firstOccurrence(vector<int> arr, int wanted) {
        int start = 0, end = arr.size() - 1;
        int result = -1; // Initialize the result to -1 (not found)

        while (start <= end) {
            int mid = start + (end - start) / 2;
            if (arr[mid] == wanted) {
                result = mid; // Update the result to the current mid
                end = mid - 1; // Move left to find the first occurrence
            } else if (wanted < arr[mid]) {
                end = mid - 1;
            } else {
                start = mid + 1;
            }
        }

        return result; // Return the index of the first occurrence or -1 if not found
    }

    int lastOccurrence(vector<int> arr, int wanted) {
        int start = 0, end = arr.size() - 1;
        int result = -1; // Initialize the result to -1 (not found)

        while (start <= end) {
            int mid = start + (end - start) / 2;
            if (arr[mid] == wanted) {
                result = mid; // Update the result to the current mid
                start = mid + 1; // Move right to find the last occurrence
            } else if (wanted < arr[mid]) {
                end = mid - 1;
            } else {
                start = mid + 1;
            }
        }

        return result; // Return the index of the last occurrence or -1 if not found
    }
};

int main() {
    vector<int> arr = {1, 2, 2, 3, 3, 3, 4, 4, 5};
    int wanted = 3;

    Occurrence occurrence;

    int firstIndex = occurrence.firstOccurrence(arr, wanted);
    int lastIndex = occurrence.lastOccurrence(arr, wanted);

    if (firstIndex == -1 || lastIndex == -1) {
        cout << "Element not found in the array." << endl;
    } else {
        cout << "First occurrence of " << wanted << " is at index " << firstIndex << endl;
        cout << "Last occurrence of " << wanted << " is at index " << lastIndex << endl;
    }

    return 0;
}


