// #include <iostream>
// #include <vector>
// using namespace std;

// class Bce {
// public:
//      int secondlargest(vector<int> ary) {
//         int max = ary[0];
//         int smax = ary[0];

//         for (int i = 0; i < ary.size(); i++) {
//             if (max < ary[i])
//                 max = ary[i];
//         }

//         for (int i = 0; i < ary.size(); i++) {
//             if (smax < ary[i]) {
//                 if (ary[i] != max)
//                     smax = ary[i];
//             }
//         }

//         return smax;
//     }
// };

// int main() {
//     Bce obj;
//     vector<int> ary = {45, 78, 12, 88, 92};
//       int largest = obj.secondlargest(ary);

//     cout << "Second Largest Element: " << largest << endl;

//     return 0;
// }
//---------------------------------------------------------------------------------------------------------------------------------
#include <iostream>
#include <vector>
using namespace std;

class Bce {
public:
    int secondlargest(vector<int> ary) {
        int max = ary[0];
        int smax = ary[0];

        for (int i = 1; i < ary.size(); i++) { // Start the loop from index 1
            if (ary[i] > max) {
                smax = max; // Update smax if a new max is found
                max = ary[i];
            } else if (ary[i] > smax && ary[i] != max) {
                smax = ary[i]; // Update smax if a new second max is found
            }
        }

        return smax;
    }
};

int main() {
    Bce obj;
    vector<int> ary = {45, 78, 12, 88, 92};
    int largest = obj.secondlargest(ary);

    cout << "Second Largest Element: " << largest << endl;

    return 0;
}

