#include <iostream>
#include <stack> // Include the stack header

using namespace std;

void PushInStack(int x, stack<int> &stk);

void doRev(stack<int> &stk) {
    if (stk.empty())
        return;
    int x = stk.top();
    stk.pop();
    doRev(stk);
    PushInStack(x, stk);
}

void PushInStack(int x, stack<int> &stk) {
    if (stk.empty()) {
        stk.push(x);
        return;
    }
    int y = stk.top();
    stk.pop();
    PushInStack(x, stk);
    stk.push(y);
}

void showstack(stack<int> stk) {
    while (!stk.empty()) {
        int x = stk.top();
        cout << x << " ";
        stk.pop();
    }
    cout << endl;
}

int main() {
    stack<int> myStack;
    // Push elements into the stack
    myStack.push(1);
    myStack.push(2);
    myStack.push(3);

    cout << "Original stack: ";
    showstack(myStack);

    // Call reverse function
    doRev(myStack);

    cout << "Reversed stack: ";
    showstack(myStack);

    return 0;
}


