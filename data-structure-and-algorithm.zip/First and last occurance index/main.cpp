#include <iostream>
#include <vector>

using namespace std;


void findFirstAndLast( vector<int>& arr, int wanted) {
    int first = -1, last = -1;
    for (int i = 0; i < arr.size(); i++) {
        if (wanted != arr[i])
            continue;
        if (first == -1)
            first = i;
            last = i;
    }
    if (first != -1)
        cout << "First Occurrence = " << first
             << "\nLast Occurrence = " << last;
    else
        cout << "Not Found";
}

// Driver code
int main() {
    vector<int> arr = {1, 2, 2, 2, 2, 3, 4, 7, 8, 8};
    int x = 2;

    findFirstAndLast(arr, x);
    return 0;
}
