#include <iostream>

using namespace std;

struct ListNode {
    int val;
    ListNode* next;
    ListNode(int x) : val(x), next(nullptr) {}
};

class Merge {
public:
    ListNode* mergeTwoLists(ListNode* list1, ListNode* list2) {
        ListNode* p1 = list1;
        ListNode* p2 = list2;
        ListNode* dummyNode = new ListNode(-1);
        ListNode* p3 = dummyNode;

        while (p1 != nullptr && p2 != nullptr) {
            if (p1->val < p2->val) {
                p3->next = p1;
                p1 = p1->next;
            } else {
                p3->next = p2;
                p2 = p2->next;
            }
            p3 = p3->next;
        }

        while (p1 != nullptr) {
            p3->next = p1;
            p1 = p1->next;
            p3 = p3->next;
        }

        while (p2 != nullptr) {
            p3->next = p2;
            p2 = p2->next;
            p3 = p3->next;
        }

        return dummyNode->next;
    }
};

// Function to print a linked list
void printList(ListNode* head) {
    ListNode* current = head;
    while (current != nullptr) {
        cout << current->val << " ";
        current = current->next;
    }
    cout << endl;
}

int main() {
    Merge m;

    ListNode* list1 = new ListNode(1);
    list1->next = new ListNode(3);
    list1->next->next = new ListNode(5);

    ListNode* list2 = new ListNode(2);
    list2->next = new ListNode(4);
    list2->next->next = new ListNode(6);

    ListNode* mergedList = m.mergeTwoLists(list1, list2);

    cout << "Merged List: ";
    printList(mergedList);

    // Clean up memory (delete nodes)
    while (mergedList != nullptr) {
        ListNode* temp = mergedList;
        mergedList = mergedList->next;
        delete temp;
    }

    return 0;
}

