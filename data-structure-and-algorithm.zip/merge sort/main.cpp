#include <iostream>
#include <vector>

using namespace std;

class Mergesort {
public:
    void merge(vector<int>& arr, int s, int e) {
        if (s >= e)
            return;

        int mid = s + (e - s) / 2;
        merge(arr, s, mid);
        merge(arr, mid + 1, e);
        domerge(arr, s, mid, mid + 1, e);
    }

    void domerge(vector<int>& arr, int sfp, int efp, int ssp, int esp) {
        int l;
        vector<int> temp;
        int i = sfp, j = ssp;

        while (i <= efp && j <= esp) {
            if (arr[i] < arr[j])
                temp.push_back(arr[i++]);
            else
                temp.push_back(arr[j++]);
        }

        for (l = i; l <= efp; l++) 
            temp.push_back(arr[l]);

        for (l = j; l <= esp; l++) 
            temp.push_back(arr[l]);

        for (int k = 0; k < temp.size(); k++) {
            arr[sfp + k] = temp[k];
        }
    }

    void doshow(vector<int>& arr) {
        cout << "Sorted array: ";
        for (auto val : arr)
            cout << val << " ";
        cout << endl;
    }
};

int main() {
    vector<int> arr = { 38, 27, 43, 3, 9, 82, 10 };
    Mergesort ms;
    ms.merge(arr, 0, arr.size() - 1);
    ms.doshow(arr);

    return 0;
}


