#include <iostream>
using namespace std;

template<class T>
void swapValues(T& a, T& b) {
    T temp = a;
    a = b;
    b = temp;
}

int main() {
    int i1 = 4, i2 = 8;
    char c1 = 'A', c2 = 'H';
    float f1 = 12.3, f2 = 45.9;

    cout << "Before swap (int): " << i1 << " " << i2 << endl;
    swapValues(i1, i2);
    cout << "After swap (int): " << i1 << " " << i2 << endl;

    cout << "Before swap (char): " << c1 << " " << c2 << endl;
    swapValues(c1, c2);
    cout << "After swap (char): " << c1 << " " << c2 << endl;

    cout << "Before swap (float): " << f1 << " " << f2 << endl;
    swapValues(f1, f2);
    cout << "After swap (float): " << f1 << " " << f2 << endl;

    return 0;
}
