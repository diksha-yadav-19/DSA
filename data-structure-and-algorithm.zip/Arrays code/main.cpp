#include <iostream>

using namespace std;
//www.bangloreComputerEducation.com
class ARRAYS
{
    int *ary;//instance var
    int cap,cursor=0,i;
    public:
    ARRAYS(int len)
    {
        cap=len;
        ary=new int[cap];//creation of new array dynamically-app of pointer to array
    }
    void show()
    {
        cout<<"\nOutput:\n";
        for(i=0;i<cursor;i++)
        {
            cout<<ary[i]<<" ";
        }
    }
    void pushBack(int value)
    {
        if(cursor==cap)
        {
           doScale();
        }
        cout<<"\n"<<value<<" Inserted at "<<cursor<<"  Position\n";
        ary[cursor]=value;
        cursor++;
        cout<<"\nCursor Position="<<cursor;
        show();
    }
    void remove(int shaheedIndex)
    {
        for(i=shaheedIndex+1;i<cursor;i++)
            {
                ary[i-1]=ary[i];
            }
            cursor--;
        
        cout<<"\nRemoved SuccessFullllyyyy..."  ;
        cout<<"\nCursor Position="<<cursor;
        
        show();
            
    }
    void doScale()
    {
        cap=cap*2;
        int *nayaAry=new int[cap];
        for(i=0;i<cursor;i++)
        {
            nayaAry[i]=ary[i];
        }
        delete []ary;
        ary=nayaAry;
        nayaAry=0;
        cout<<"\n ****Array Scaled to doble capacity....****";
    }
    
    void doFindFirstOccuranceAndDelete(int value)
    {
        int pos=getIndex(value);
        remove(pos);
        show();
    }
    void doFindOccuranceAndDeleteAll(int value)
    {
        while(1)
            {
                int pos=getIndex(value);
                if(pos==-1)
                    break;
                remove(pos);
            }
    }
    void doDelAll()
      {
                 cursor = 0; 
                cout << "\nAll elements deleted successfully.\n";
                show();
      }
    
    int getIndex(int wanted)
    {
        for(int i=0;i<cursor;i++)
            {
                if(wanted==ary[i])
                    return i;
            }
            return -1;
    }
    
    void doInsert(int pos,int value)
      {
            for(int i=cursor-1;i>=pos;i--)
            {
                ary[i+1]=ary[i];
            }
            ary[pos]=value;
            cursor++;
            show();
      }
};
int main()
{
    ARRAYS obj(8);
    
   
    obj.pushBack(10);
    obj.pushBack(10);
    obj.pushBack(10);
    obj.pushBack(60);
    obj.pushBack(20);
    obj.pushBack(11);
    
     
    // obj.doFindFirstOccuranceAndDelete(10);
    // obj.doFindOccuranceAndDeleteAll(10);
     obj.doInsert(2,222);
      obj.doDelAll();
    
    
    
    
}


