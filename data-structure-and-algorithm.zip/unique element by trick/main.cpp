#include <iostream>
#include <vector>
using namespace std;

class BCE {
public:
    void Unique(vector<int> ary) {
        int x = 0;
        for (int i = 0; i < ary.size(); i++) {
            x = x ^ ary[i];
        }
        cout << "Unique =" << x;
    }

    void show(vector<int> ary) {
        for (int i = 0; i < ary.size(); i++) {
            cout << ary[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    vector<int> ary = {3, 7, 7, 4, 3};
    BCE obj;

    // obj.Unique(ary);
    obj.show(ary);
    obj.Unique(ary);
    return 0;
}
